<?php
/**
  Plugin Name: File Manager Advanced Shortcode
  Plugin URI: https://advancedfilemanager.com/product/file-manager-advanced-shortcode-wordpress/
  Description: Shortcodes for advanced file manager
  Author: modalweb
  Version: 2.3.2
  Author URI: https://advancedfilemanager.com/
**/
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
define('fmas_file',__FILE__);
define('fmas_ver','2.3.2');
if(!class_exists('file_manager_advanced_shortcode')) {
class file_manager_advanced_shortcode {
	var $ver = '2.3.2';
    /* constructor */
	public function __construct() {
       add_action( 'init', array($this,'file_manager_advanced_directory'));
	   add_shortcode('file_manager_advanced',array($this,'file_manager_advanced_return'));
	   add_action( 'init', array(&$this,'fma_shortcode_updates'));
       add_shortcode( 'fma_user_role', array($this,'fma_check_user_role'));
       add_shortcode( 'fma_user', array($this,'fma_check_user'));
	}
    /* shortcode */
	public function file_manager_advanced_return($atts) {
        if(class_exists('class_fma_shortcode') && !is_admin()) {
            wp_enqueue_script('jquery');
        $fma_adv = '';
        $shortcodeAtts = shortcode_atts( array(
                'id' => 'file_manager_advanced',
                'login' => 'yes',
                'roles' => 'all',
                'path' => '%',
                'url' => '',
                'path_type' => 'inside',
                'write' => 'false',
                'read' => 'true',
                'hide' => '',
                'operations' => 'all',
                'block_users' => '',
                'view' => 'grid',
                'theme' => 'light',
                'lang' => 'en',
                'dateformat' => 'M d, Y h:i A',
                'hide_path' =>  'no',
                'enable_trash' => 'no',
                'height' => '',
                'width' => '',
                'ui' => '',
                'upload_allow' => 'all',
                'upload_max_size' => '0',
            ), $atts );

        $fma_id = !empty($shortcodeAtts['id']) ? $shortcodeAtts['id'] : 'file_manager_advanced';

                    $elfCss = [
                        'commands.css',
                        'common.css',
                        'contextmenu.css',
                        'cwd.css',
                        'dialog.css',
                        'fonts.css',
                        'navbar.css',
                        'quicklook.css',
                        'statusbar.css',
                        'toast.css',
                        'toolbar.css'
                    ];

                wp_enqueue_style( 'query-ui-1.12.0', plugins_url('library/jquery/jquery-ui-1.12.0.css', fma_file));

                foreach($elfCss as $elCss) {
                    wp_enqueue_style( $elCss, plugins_url('library/css/'.$elCss.'', fma_file));	
                }
                wp_enqueue_style( 'fma_theme', plugins_url('library/css/theme.css', fma_file));
                if(isset($shortcodeAtts['theme']) && $shortcodeAtts ['theme'] == 'dark') {
                wp_enqueue_style( 'fma_themee_'.$fma_id, plugins_url('library/themes/dark/css/theme.css', fma_file));
                }
                else if(isset($shortcodeAtts['theme']) && $shortcodeAtts ['theme'] == 'grey') {
                wp_enqueue_style( 'fma_themee', plugins_url('library/themes/grey/css/theme.css', fma_file));
                }
                else if(isset($shortcodeAtts['theme']) && $shortcodeAtts ['theme'] == 'windows10') {
                wp_enqueue_style( 'fma_themee', plugins_url('library/themes/windows10/css/theme.css', fma_file));
                }
                else if(isset($shortcodeAtts['theme']) && $shortcodeAtts ['theme'] == 'bootstrap') {
                wp_enqueue_style( 'fma_themee', plugins_url('library/themes/bootstrap/css/theme.css', fma_file));
                }
                wp_enqueue_style( 'fma_custom', plugins_url('library/css/custom_style_filemanager_advanced.css', fma_file));

                wp_enqueue_script('afm-init-jquery', plugins_url('library/js/init.js', fma_file));

                wp_enqueue_script( 'afm-elFinder', plugins_url('library/js/elFinder.js', fma_file), array('jquery', 'jquery-ui-core', 'jquery-ui-selectable', 'jquery-ui-draggable', 'jquery-ui-droppable', 'jquery-ui-resizable', 'jquery-ui-dialog', 'jquery-ui-slider', 'jquery-ui-tabs'));

                wp_enqueue_script( 'afm-elFinder.version', plugins_url('library/js/elFinder.version.js', fma_file));
                wp_enqueue_script( 'afm-jquery.elfinder', plugins_url('library/js/jquery.elfinder.js', fma_file));
                wp_enqueue_script( 'afm-elFinder.mimetypes', plugins_url('library/js/elFinder.mimetypes.js', fma_file));
                wp_enqueue_script( 'afm-elFinder.options', plugins_url('library/js/elFinder.options.js', fma_file));
                wp_enqueue_script( 'afm-elFinder.options.netmount', plugins_url('library/js/elFinder.options.netmount.js', fma_file));
                wp_enqueue_script( 'afm-elFinder.history', plugins_url('library/js/elFinder.history.js', fma_file));
                wp_enqueue_script( 'afm-elFinder.command', plugins_url('library/js/elFinder.command.js', fma_file));
                wp_enqueue_script( 'afm-elFinder.resources', plugins_url('library/js/elFinder.resources.js', fma_file));
            
                wp_enqueue_script( 'afm-jquery.dialogelfinder', plugins_url('library/js/jquery.dialogelfinder.js', fma_file));
            

                wp_enqueue_script( 'afm-button', plugins_url('library/js/ui/button.js', fma_file));
                wp_enqueue_script( 'afm-contextmenu', plugins_url('library/js/ui/contextmenu.js', fma_file));
                wp_enqueue_script( 'afm-cwd', plugins_url('library/js/ui/cwd.js', fma_file));
                wp_enqueue_script( 'afm-dialog', plugins_url('library/js/ui/dialog.js', fma_file));
                wp_enqueue_script( 'afm-fullscreenbutton', plugins_url('library/js/ui/fullscreenbutton.js', fma_file));
                wp_enqueue_script( 'afm-navbar', plugins_url('library/js/ui/navbar.js', fma_file));
                wp_enqueue_script( 'afm-navdock', plugins_url('library/js/ui/navdock.js', fma_file));
                wp_enqueue_script( 'afm-overlay', plugins_url('library/js/ui/overlay.js', fma_file));
                wp_enqueue_script( 'afm-panel', plugins_url('library/js/ui/panel.js', fma_file));
                wp_enqueue_script( 'afm-path', plugins_url('library/js/ui/path.js', fma_file));
                wp_enqueue_script( 'afm-searchbutton', plugins_url('library/js/ui/searchbutton.js', fma_file));
                wp_enqueue_script( 'afm-sortbutton', plugins_url('library/js/ui/sortbutton.js', fma_file));
                wp_enqueue_script( 'afm-stat', plugins_url('library/js/ui/stat.js', fma_file));
                wp_enqueue_script( 'afm-toast', plugins_url('library/js/ui/toast.js', fma_file));
                wp_enqueue_script( 'afm-toolbar', plugins_url('library/js/ui/toolbar.js', fma_file));
                wp_enqueue_script( 'afm-tree', plugins_url('library/js/ui/tree.js', fma_file));
                wp_enqueue_script( 'afm-uploadButton', plugins_url('library/js/ui/uploadButton.js', fma_file));
                wp_enqueue_script( 'afm-viewbutton', plugins_url('library/js/ui/viewbutton.js', fma_file));
                wp_enqueue_script( 'afm-workzone', plugins_url('library/js/ui/workzone.js', fma_file));
            

                wp_enqueue_script( 'afm-archive', plugins_url('library/js/commands/archive.js', fma_file));
                wp_enqueue_script( 'afm-back', plugins_url('library/js/commands/back.js', fma_file));
                wp_enqueue_script( 'afm-chmod', plugins_url('library/js/commands/chmod.js', fma_file));
                wp_enqueue_script( 'afm-colwidth', plugins_url('library/js/commands/colwidth.js', fma_file));
                wp_enqueue_script( 'afm-copy', plugins_url('library/js/commands/copy.js', fma_file));
                wp_enqueue_script( 'afm-cut', plugins_url('library/js/commands/cut.js', fma_file));
                wp_enqueue_script( 'afm-download', plugins_url('library/js/commands/download.js', fma_file));
                wp_enqueue_script( 'afm-duplicate', plugins_url('library/js/commands/duplicate.js', fma_file));
                wp_enqueue_script( 'afm-edit', plugins_url('library/js/commands/edit.js', fma_file));
                wp_enqueue_script( 'afm-empty', plugins_url('library/js/commands/empty.js', fma_file));
                wp_enqueue_script( 'afm-extract', plugins_url('library/js/commands/extract.js', fma_file));
                wp_enqueue_script( 'afm-forward', plugins_url('library/js/commands/forward.js', fma_file));
                wp_enqueue_script( 'afm-fullscreen', plugins_url('library/js/commands/fullscreen.js', fma_file));
                wp_enqueue_script( 'afm-getfile', plugins_url('library/js/commands/getfile.js', fma_file));
                wp_enqueue_script( 'afm-help', plugins_url('library/js/commands/help.js', fma_file));
                wp_enqueue_script( 'afm-hidden', plugins_url('library/js/commands/hidden.js', fma_file));
                //wp_enqueue_script( 'afm-hide', plugins_url('library/js/commands/hide.js', fma_file));
                wp_enqueue_script( 'afm-home', plugins_url('library/js/commands/home.js', fma_file));
                wp_enqueue_script( 'afm-info', plugins_url('library/js/commands/info.js', fma_file));
                wp_enqueue_script( 'afm-mkdir', plugins_url('library/js/commands/mkdir.js', fma_file));
                wp_enqueue_script( 'afm-mkfile', plugins_url('library/js/commands/mkfile.js', fma_file));
                wp_enqueue_script( 'afm-netmount', plugins_url('library/js/commands/netmount.js', fma_file));
                wp_enqueue_script( 'afm-open', plugins_url('library/js/commands/open.js', fma_file));
                wp_enqueue_script( 'afm-opendir', plugins_url('library/js/commands/opendir.js', fma_file));
                wp_enqueue_script( 'afm-opennew', plugins_url('library/js/commands/opennew.js', fma_file));
                wp_enqueue_script( 'afm-paste', plugins_url('library/js/commands/paste.js', fma_file));
                wp_enqueue_script( 'afm-quicklook', plugins_url('library/js/commands/quicklook.js', fma_file));
                wp_enqueue_script( 'afm-quicklook.plugins', plugins_url('library/js/commands/quicklook.plugins.js', fma_file));
                wp_enqueue_script( 'afm-reload', plugins_url('library/js/commands/reload.js', fma_file));
                wp_enqueue_script( 'afm-rename', plugins_url('library/js/commands/rename.js', fma_file));
                wp_enqueue_script( 'afm-resize', plugins_url('library/js/commands/resize.js', fma_file));
                wp_enqueue_script( 'afm-restore', plugins_url('library/js/commands/restore.js', fma_file));
                wp_enqueue_script( 'afm-rm', plugins_url('library/js/commands/rm.js', fma_file));
                wp_enqueue_script( 'afm-search', plugins_url('library/js/commands/search.js', fma_file));
                wp_enqueue_script( 'afm-selectall', plugins_url('library/js/commands/selectall.js', fma_file));
                wp_enqueue_script( 'afm-selectinvert', plugins_url('library/js/commands/selectinvert.js', fma_file));
                wp_enqueue_script( 'afm-selectnone', plugins_url('library/js/commands/selectnone.js', fma_file));
                wp_enqueue_script( 'afm-sort', plugins_url('library/js/commands/sort.js', fma_file));
                wp_enqueue_script( 'afm-undo', plugins_url('library/js/commands/undo.js', fma_file));
                wp_enqueue_script( 'afm-up', plugins_url('library/js/commands/up.js', fma_file));
                wp_enqueue_script( 'afm-upload', plugins_url('library/js/commands/upload.js', fma_file));
                wp_enqueue_script( 'afm-view', plugins_url('library/js/commands/view.js', fma_file));
                wp_enqueue_script( 'afm-quicklook.googledocs', plugins_url('library/js/extras/quicklook.googledocs.js', fma_file));

                if(isset($shortcodeAtts['lang'])) {
                    $locale = $shortcodeAtts['lang'];
                    wp_enqueue_script( 'fma_lang_'.$shortcodeAtts['lang'], plugins_url('library/js/i18n/elfinder.'.$locale.'.js', fma_file));
                }

                wp_enqueue_script( 'codemirror', plugins_url('library/codemirror/lib/codemirror.js',  fma_file ));
                wp_enqueue_style( 'codemirror', plugins_url('library/codemirror/lib/codemirror.css', fma_file));
                wp_enqueue_script( 'htmlmixed', plugins_url('library/codemirror/mode/htmlmixed/htmlmixed.js',  fma_file ));
                wp_enqueue_script( 'xml', plugins_url('library/codemirror/mode/xml/xml.js',  fma_file ));
                wp_enqueue_script( 'css', plugins_url('library/codemirror/mode/css/css.js',  fma_file ));
                wp_enqueue_script( 'javascript', plugins_url('library/codemirror/mode/javascript/javascript.js',  fma_file ));
                wp_enqueue_script( 'clike', plugins_url('library/codemirror/mode/clike/clike.js',  fma_file ));
                wp_enqueue_script( 'php', plugins_url('library/codemirror/mode/php/php.js',  fma_file ));	
        
                $generated_script_id = $fma_id."-fma-shortcode-js";

                wp_register_script( $generated_script_id, plugins_url('js/shortcode.js', fmas_file ), array('jquery') );

                wp_enqueue_script( $generated_script_id );
                include('pages/shortcode.php');
                return $fma_adv;
        } else {
            $plugin_url_text = '<strong>Please install <a href="https://wordpress.org/plugins/file-manager-advanced/"> File Manager Advanced </a> Plugin to make shortcode work.</strong>';
            return $plugin_url_text;
        }
    }
    /* Directory */
    public function file_manager_advanced_directory() {
         if(is_user_logged_in()) {
                    $current_user = wp_get_current_user();
                    $upload_dir   = wp_upload_dir();
                    if ( isset( $current_user->user_login ) && ! empty( $upload_dir['basedir'] ) ) {
                        $user_dirname = $upload_dir['basedir'].'/file-manager-advanced/users/'.$current_user->user_login;
                            if ( ! file_exists( $user_dirname ) ) {
                              wp_mkdir_p( $user_dirname );
                        }
                    }
        }
    }
	/* User Role Shortcode */
	// use: [fma_user_role role="subscriber, author"]shortcode[/fma_user_role]
	public function fma_check_user_role( $atts, $content = null ) {
        extract( shortcode_atts( array(
                'role' => 'role' ), $atts ) );
        $user = wp_get_current_user();
        $roles = explode(',', $role);
        $allowed_roles = $roles;
        if( array_intersect($allowed_roles, $user->roles ) ) {
                return apply_filters('the_content',$content);
        }
   }
   /* User Shortcode */
	// use: [fma_user user="1,2"]shortcode[/fma_user]
	public function fma_check_user( $atts, $content = null ) {
        extract( shortcode_atts( array(
                'user' => 'user' ), $atts ) );
        $cuser = wp_get_current_user();
        $users = explode(',', $user);
        $allowed_users = $users;
        if( in_array($cuser->ID, $allowed_users ) ) {
                return apply_filters('the_content',$content);
        }
   }
	   public function fma_shortcode_updates()
	   {
		    $path = $_SERVER['REQUEST_URI'];
			$file = basename($path, ".php");
			$file_name = explode('?', $file);
			if(($file_name[0] == 'plugins.php') || ($file_name[0] == 'plugins')) {
		    require_once ( 'upgrade/upgrade.php');
			$fma_plugin_current_version = $this->ver;
			$fma_plugin_remote_path = 'https://advancedfilemanager.com/upgrade/';
			$fma_plugin_slug = plugin_basename( __FILE__ );
			$fma_license_order = '1';
			$fma_license_key = 'success';
		      new file_manager_advanced_shortcode_updates( $fma_plugin_current_version, $fma_plugin_remote_path, $fma_plugin_slug, $fma_license_order, $fma_license_key );
			}
	   }
	}
new file_manager_advanced_shortcode;
}