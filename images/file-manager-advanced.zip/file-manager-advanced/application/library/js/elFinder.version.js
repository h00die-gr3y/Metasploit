/**
 * Application version
 *
 * @type String
 **/
elFinder.prototype.version = '2.1.61';

